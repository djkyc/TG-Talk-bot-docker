const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const input = require("input");

console.log("=====================================================");
console.log("   TeleBox Session String 生成工具 (本地版)         ");
console.log("=====================================================");

(async () => {
  console.log("请按提示输入信息以登录 Telegram：\n");

  // 1. 获取 API ID/Hash
  const apiId = await input.text("请输入您的 API ID (从 my.telegram.org 获取):");
  const apiHash = await input.text("请输入您的 API HASH:");

  // 2. 询问是否使用代理 (国内用户需要)
  const useProxy = await input.text("是否使用代理? (y/n，国内用户请输入 y):");

  let proxyConfig = undefined;
  if (useProxy.toLowerCase() === 'y') {
    console.log("\n请输入 SOCKS5 代理信息 (V2Ray/Clash 通常是 127.0.0.1:10808 或 1080):");
    const proxyHost = await input.text("代理地址 (默认 127.0.0.1):", { default: "127.0.0.1" });
    const proxyPort = await input.text("代理端口 (如 10808, 7890, 1080):");

    proxyConfig = {
      socksType: 5,
      ip: proxyHost || "127.0.0.1",
      port: parseInt(proxyPort),
    };
    console.log(`\n✅ 使用 SOCKS5 代理: ${proxyConfig.ip}:${proxyConfig.port}`);
  }

  // 3. 创建客户端
  const clientOptions = {
    connectionRetries: 5,
  };

  if (proxyConfig) {
    clientOptions.proxy = proxyConfig;
  }

  const client = new TelegramClient(
    new StringSession(""),
    Number(apiId),
    apiHash,
    clientOptions
  );

  // 4. 开始交互式登录
  await client.start({
    phoneNumber: async () => await input.text("请输入您的手机号 (如 +8613800000000):"),
    password: async () => await input.text("请输入两步验证密码 (如未设置可直接回车):"),
    phoneCode: async () => await input.text("请输入您收到的验证码:"),
    onError: (err) => console.log(err),
  });

  console.log("\n-----------------------------------------------------");
  console.log("✅ 登录成功！");
  console.log("-----------------------------------------------------");
  console.log("您的 SESSION_STRING 如下，请完整复制：\n");
  console.log(client.session.save());
  console.log("\n-----------------------------------------------------");
  console.log("⚠️  请妥善保管此字符串！任何人拿到它都可以访问您的账户。");
  console.log("   现在将其粘贴到容器平台的环境变量 SESSION_STRING 中即可。");

  process.exit(0);
})();
